import AppKit
import Foundation

let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
let folder = root.appendingPathComponent("screenshots")
let files = try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil)
    .filter { $0.pathExtension == "log" }
    .sorted { $0.lastPathComponent < $1.lastPathComponent }

let font = NSFont.monospacedSystemFont(ofSize: 18, weight: .regular)
let titleFont = NSFont.systemFont(ofSize: 25, weight: .semibold)
let metaFont = NSFont.monospacedSystemFont(ofSize: 14, weight: .regular)
let background = NSColor(calibratedRed: 0.055, green: 0.075, blue: 0.11, alpha: 1)
let header = NSColor(calibratedRed: 0.11, green: 0.14, blue: 0.20, alpha: 1)
let regular = NSColor(calibratedRed: 0.89, green: 0.92, blue: 0.95, alpha: 1)
let command = NSColor(calibratedRed: 0.48, green: 0.86, blue: 0.64, alpha: 1)
let caption = NSColor(calibratedRed: 0.62, green: 0.71, blue: 0.82, alpha: 1)

for source in files {
    let name = source.deletingPathExtension().lastPathComponent
    let body = try String(contentsOf: source, encoding: .utf8)
    var lines = body.components(separatedBy: .newlines)
    if lines.last == "" { lines.removeLast() }

    let textWidth = lines.map { line in
        (line as NSString).size(withAttributes: [.font: font]).width
    }.max() ?? 0
    let width = Int(ceil(max(1100, textWidth + 96)))
    let lineHeight: CGFloat = 26
    let top: CGFloat = 108
    let bottom: CGFloat = 42
    let height = Int(ceil(top + CGFloat(lines.count) * lineHeight + bottom))

    guard let bitmap = NSBitmapImageRep(
        bitmapDataPlanes: nil, pixelsWide: width, pixelsHigh: height,
        bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true,
        isPlanar: false, colorSpaceName: .deviceRGB,
        bytesPerRow: 0, bitsPerPixel: 0
    ), let context = NSGraphicsContext(bitmapImageRep: bitmap) else {
        throw NSError(domain: "RenderLogs", code: 1)
    }

    NSGraphicsContext.saveGraphicsState()
    NSGraphicsContext.current = context
    background.setFill()
    NSRect(x: 0, y: 0, width: width, height: height).fill()
    header.setFill()
    NSRect(x: 0, y: height - 85, width: width, height: 85).fill()

    ("Elasticsearch · \(name.replacingOccurrences(of: "_", with: " "))" as NSString).draw(
        at: NSPoint(x: 44, y: CGFloat(height) - 47),
        withAttributes: [.font: titleFont, .foregroundColor: regular]
    )
    ("Фактический вывод: screenshots/\(name).log" as NSString).draw(
        at: NSPoint(x: 44, y: CGFloat(height) - 72),
        withAttributes: [.font: metaFont, .foregroundColor: caption]
    )

    for (index, line) in lines.enumerated() {
        let color = line.hasPrefix("$") || line.hasPrefix("GET /") || line.hasPrefix("POST /") || line.hasPrefix("PUT /") || line.hasPrefix("DELETE /") ? command : regular
        (line as NSString).draw(
            at: NSPoint(x: 44, y: CGFloat(height) - top - CGFloat(index + 1) * lineHeight),
            withAttributes: [.font: font, .foregroundColor: color]
        )
    }
    context.flushGraphics()
    NSGraphicsContext.restoreGraphicsState()

    guard let png = bitmap.representation(using: .png, properties: [:]) else {
        throw NSError(domain: "RenderLogs", code: 2)
    }
    try png.write(to: folder.appendingPathComponent("\(name).png"))
    print("screenshots/\(name).png: \(width)×\(height)")
}
