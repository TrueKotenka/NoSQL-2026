import AppKit
import Foundation

let folder = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    .appendingPathComponent("screenshots")
let names = ["01_cluster", "02_schema", "03_hour", "04_error", "05_down", "06_restored"]
let font = NSFont.monospacedSystemFont(ofSize: 18, weight: .regular)
let titleFont = NSFont.systemFont(ofSize: 25, weight: .semibold)
let metaFont = NSFont.monospacedSystemFont(ofSize: 13, weight: .regular)
let background = NSColor(calibratedRed: 0.055, green: 0.075, blue: 0.11, alpha: 1)
let header = NSColor(calibratedRed: 0.11, green: 0.14, blue: 0.20, alpha: 1)
let regular = NSColor(calibratedRed: 0.89, green: 0.92, blue: 0.95, alpha: 1)
let command = NSColor(calibratedRed: 0.48, green: 0.86, blue: 0.64, alpha: 1)
let caption = NSColor(calibratedRed: 0.62, green: 0.71, blue: 0.82, alpha: 1)

func wrap(_ line: String, limit: Int = 118) -> [String] {
    var remaining = line
    var output: [String] = []
    while remaining.count > limit {
        let prefix = String(remaining.prefix(limit))
        if let space = prefix.lastIndex(of: " "), prefix.distance(from: prefix.startIndex, to: space) > limit / 2 {
            output.append(String(prefix[..<space]))
            remaining = String(remaining[remaining.index(remaining.startIndex, offsetBy: prefix.distance(from: prefix.startIndex, to: space) + 1)...])
        } else {
            output.append(prefix)
            remaining = String(remaining.dropFirst(limit))
        }
        remaining = "    " + remaining.trimmingCharacters(in: .whitespaces)
    }
    output.append(remaining)
    return output
}

for name in names {
    let body = try String(contentsOf: folder.appendingPathComponent("\(name).log"), encoding: .utf8)
    var sourceLines = body.components(separatedBy: .newlines)
    if sourceLines.last == "" { sourceLines.removeLast() }
    let lines = sourceLines.flatMap { wrap($0) }
    let textWidth = lines.map {
        ($0 as NSString).size(withAttributes: [.font: font]).width
    }.max() ?? 0
    let width = Int(ceil(max(1200, textWidth + 96)))
    let lineHeight: CGFloat = 26
    let top: CGFloat = 108
    let height = Int(ceil(top + CGFloat(lines.count) * lineHeight + 42))

    guard let bitmap = NSBitmapImageRep(
        bitmapDataPlanes: nil, pixelsWide: width, pixelsHigh: height,
        bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true,
        isPlanar: false, colorSpaceName: .deviceRGB,
        bytesPerRow: 0, bitsPerPixel: 0
    ), let context = NSGraphicsContext(bitmapImageRep: bitmap) else {
        throw NSError(domain: "RenderLogs", code: 1)
    }
    NSGraphicsContext.saveGraphicsState()
    NSGraphicsContext.current = context
    background.setFill()
    NSRect(x: 0, y: 0, width: width, height: height).fill()
    header.setFill()
    NSRect(x: 0, y: height - 84, width: width, height: 84).fill()
    ("Cassandra · \(name.replacingOccurrences(of: "_", with: " "))" as NSString).draw(
        at: NSPoint(x: 44, y: CGFloat(height) - 47),
        withAttributes: [.font: titleFont, .foregroundColor: regular]
    )
    ("Фактический вывод: screenshots/\(name).log" as NSString).draw(
        at: NSPoint(x: 44, y: CGFloat(height) - 70),
        withAttributes: [.font: metaFont, .foregroundColor: caption]
    )
    for (index, line) in lines.enumerated() {
        let color = line.hasPrefix("$") ? command : regular
        (line as NSString).draw(
            at: NSPoint(x: 44, y: CGFloat(height) - top - CGFloat(index + 1) * lineHeight),
            withAttributes: [.font: font, .foregroundColor: color]
        )
    }
    context.flushGraphics()
    NSGraphicsContext.restoreGraphicsState()
    guard let png = bitmap.representation(using: .png, properties: [:]) else {
        throw NSError(domain: "RenderLogs", code: 2)
    }
    try png.write(to: folder.appendingPathComponent("\(name).png"))
    print("screenshots/\(name).png: \(width)×\(height)")
}
